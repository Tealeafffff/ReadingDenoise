const btnToggle = document.getElementById('btn-toggle');
const btnCurve = document.getElementById('btn-curve');
const btnBinary = document.getElementById('btn-binary');
const lvlBtns = Array.from(document.querySelectorAll('.lvl-btn'));

const LEVELS = [25, 50, 75, 100];
let current = { mode: 'precise', strength: 75, fadeStyle: 'curve' };

function nearestLevel(v) {
  return LEVELS.reduce((a, b) => (Math.abs(b - v) < Math.abs(a - v) ? b : a));
}

function render() {
  const on = current.mode === 'precise';
  btnToggle.classList.toggle('active', on);
  const level = nearestLevel(current.strength);
  for (const b of lvlBtns) {
    b.classList.toggle('active', on && Number(b.dataset.strength) === level);
    b.disabled = !on;
  }
  const style = current.fadeStyle === 'binary' ? 'binary' : 'curve';
  btnCurve.classList.toggle('active', style === 'curve');
  btnBinary.classList.toggle('active', style === 'binary');
  btnCurve.disabled = !on;
  btnBinary.disabled = !on;
}

async function save(patch) {
  const stored = await chrome.storage.local.get('rd-settings');
  const next = { ...(stored['rd-settings'] || {}), ...patch };
  await chrome.storage.local.set({ 'rd-settings': next });
  current = { ...current, ...patch };
  render();
}

// 单开关：运行 <-> 关闭
btnToggle.addEventListener('click', () => {
  save({ mode: current.mode === 'precise' ? 'off' : 'precise' });
});

for (const b of lvlBtns) {
  b.addEventListener('click', () => save({ strength: Number(b.dataset.strength) }));
}

btnCurve.addEventListener('click', () => save({ fadeStyle: 'curve' }));
btnBinary.addEventListener('click', () => save({ fadeStyle: 'binary' }));

document.getElementById('open-options').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

// ---------- 网站名单 ----------

function deepMerge(base, over) {
  if (over === null || over === undefined) return base;
  if (typeof base !== 'object' || Array.isArray(base) || base === null) return over;
  if (typeof over !== 'object' || Array.isArray(over)) return over;
  const out = { ...base };
  for (const k of Object.keys(over)) out[k] = deepMerge(base[k], over[k]);
  return out;
}

async function currentSiteOrigin() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return null;
  try {
    const u = new URL(tab.url);
    return /^https?:$/.test(u.protocol) ? u.origin : null;
  } catch (e) {
    return null;
  }
}

function flash(btn, text) {
  const old = btn.textContent;
  btn.textContent = text;
  setTimeout(() => { btn.textContent = old; }, 1200);
}

const SITE_BTN = document.getElementById('add-site');
const SITE_BTN_TEXT = { off: '加入网站名单', on: '已加入网站名单' };
const MODE_BTNS = {
  block: document.getElementById('mode-block'),
  allow: document.getElementById('mode-allow'),
};
let knownOrigin = null;

function setSiteModeUI(mode) {
  const key = mode === 'allow' ? 'allow' : 'block';
  for (const [k, b] of Object.entries(MODE_BTNS)) b.classList.toggle('active', k === key);
}

async function loadMergedSettings() {
  const defaults = await (await fetch(chrome.runtime.getURL('worker/defaults.json'))).json();
  const stored = await chrome.storage.local.get('rd-settings');
  return deepMerge(defaults, stored['rd-settings'] || {});
}

async function refreshSiteUI(originOverride) {
  const origin = originOverride || knownOrigin || await currentSiteOrigin();
  if (origin) knownOrigin = origin;
  const s = await loadMergedSettings();
  const added = !!(origin && Array.isArray(s.sitelist) && s.sitelist.some((u) => typeof u === 'string' && RDSite.sameSite(u, origin)));
  SITE_BTN.classList.toggle('active', added);
  SITE_BTN.textContent = added ? SITE_BTN_TEXT.on : SITE_BTN_TEXT.off;
  setSiteModeUI(s.siteMode);
}

async function toggleSite(originOverride) {
  const origin = originOverride || await currentSiteOrigin();
  if (!origin) { flash(SITE_BTN, '无法读取当前网址'); return; }
  knownOrigin = origin;
  const stored = await chrome.storage.local.get('rd-settings');
  const prev = stored['rd-settings'] || {};
  const s = await loadMergedSettings();
  const list = Array.isArray(s.sitelist) ? s.sitelist.slice() : [];
  const hit = (u) => typeof u === 'string' && RDSite.sameSite(u, origin);
  const next = list.some(hit) ? list.filter((u) => !hit(u)) : [...list, origin];
  // 只写名单，不动 siteMode 和其它设置
  await chrome.storage.local.set({ 'rd-settings': { ...prev, sitelist: next } });
  await refreshSiteUI();
}

SITE_BTN.addEventListener('click', () => toggleSite());

for (const [mode, btn] of Object.entries(MODE_BTNS)) {
  btn.addEventListener('click', async () => {
    const stored = await chrome.storage.local.get('rd-settings');
    const prev = stored['rd-settings'] || {};
    await chrome.storage.local.set({ 'rd-settings': { ...prev, siteMode: mode } });
    setSiteModeUI(mode);
  });
}

// 测试钩子：以标签页方式打开弹窗时拿不到 activeTab 授权，e2e 用它直接注入网址
window.__rdTestToggleSite = (origin) => toggleSite(origin);

refreshSiteUI();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes['rd-settings']) refreshSiteUI();
});

(async function init() {
  const stored = await chrome.storage.local.get('rd-settings');
  const s = stored['rd-settings'] || {};
  // 历史遗留的 'fast' 归一化为 'precise'（已移除快速模式）
  current = {
    mode: s.mode === 'off' ? 'off' : 'precise',
    strength: s.strength ?? 75,
    fadeStyle: s.fadeStyle === 'binary' ? 'binary' : 'curve',
  };
  render();
})();
