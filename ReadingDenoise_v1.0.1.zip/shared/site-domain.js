// 网站归并：把子域折算到可注册域名，game/www/t.bilibili.com 视为同一网站。
// 未收录的多段后缀按“最后两段”处理；收录的（如 com.cn、co.uk、github.io）取最后三段。
(function () {
  const MULTI = new Set([
    // 中国及港澳台
    'com.cn', 'net.cn', 'org.cn', 'gov.cn', 'edu.cn', 'ac.cn', 'mil.cn',
    'bj.cn', 'sh.cn', 'tj.cn', 'cq.cn', 'he.cn', 'sx.cn', 'nm.cn', 'ln.cn', 'jl.cn', 'hl.cn',
    'js.cn', 'zj.cn', 'ah.cn', 'fj.cn', 'jx.cn', 'sd.cn', 'ha.cn', 'hb.cn', 'hn.cn',
    'gd.cn', 'gx.cn', 'hi.cn', 'sc.cn', 'gz.cn', 'yn.cn', 'xz.cn', 'sn.cn', 'gs.cn', 'qh.cn', 'nx.cn', 'xj.cn',
    'tw.cn', 'hk.cn', 'mo.cn',
    'com.hk', 'org.hk', 'net.hk', 'edu.hk', 'gov.hk', 'idv.hk',
    'com.tw', 'org.tw', 'net.tw', 'edu.tw', 'gov.tw', 'idv.tw', 'club.tw', 'game.tw', 'ebiz.tw',
    'com.mo', 'net.mo', 'org.mo', 'edu.mo', 'gov.mo',
    // 亚洲
    'co.jp', 'ne.jp', 'or.jp', 'ac.jp', 'go.jp', 'ed.jp', 'gr.jp', 'lg.jp',
    'co.kr', 'ne.kr', 'or.kr', 're.kr', 'pe.kr', 'go.kr', 'mil.kr', 'ac.kr', 'hs.kr', 'ms.kr', 'es.kr', 'sc.kr', 'kg.kr',
    'com.sg', 'net.sg', 'org.sg', 'edu.sg', 'gov.sg', 'per.sg',
    'com.my', 'net.my', 'org.my', 'edu.my', 'gov.my',
    'co.in', 'net.in', 'org.in', 'firm.in', 'gen.in', 'ind.in', 'ac.in', 'edu.in', 'gov.in', 'res.in',
    'co.il', 'org.il', 'net.il', 'ac.il', 'gov.il', 'muni.il',
    'com.sa', 'net.sa', 'org.sa', 'edu.sa', 'gov.sa', 'med.sa', 'pub.sa',
    'co.ae', 'net.ae', 'org.ae', 'ac.ae', 'gov.ae', 'sch.ae',
    // 欧洲/大洋洲/非洲
    'co.uk', 'org.uk', 'me.uk', 'ac.uk', 'gov.uk', 'net.uk', 'ltd.uk', 'plc.uk', 'sch.uk',
    'com.au', 'net.au', 'org.au', 'edu.au', 'gov.au', 'asn.au', 'id.au',
    'co.nz', 'net.nz', 'org.nz', 'govt.nz', 'ac.nz', 'school.nz', 'geek.nz',
    'co.za', 'org.za', 'net.za', 'gov.za', 'ac.za', 'edu.za', 'web.za',
    'com.ua', 'net.ua', 'org.ua', 'edu.ua', 'gov.ua', 'in.ua',
    'com.pl', 'net.pl', 'org.pl', 'edu.pl', 'gov.pl',
    'msk.ru', 'spb.ru',
    // 美洲
    'com.br', 'net.br', 'org.br', 'gov.br', 'edu.br', 'art.br', 'blog.br',
    'com.mx', 'net.mx', 'org.mx', 'edu.mx', 'gob.mx',
    'com.ar', 'net.ar', 'org.ar', 'edu.ar', 'gob.ar',
    'com.tr', 'net.tr', 'org.tr', 'edu.tr', 'gov.tr', 'gen.tr', 'web.tr',
    'com.eg', 'net.eg', 'org.eg', 'edu.eg', 'gov.eg',
    // 托管平台：每个租户算独立网站
    'github.io', 'gitlab.io', 'blogspot.com', 'appspot.com', 'herokuapp.com', 'azurewebsites.net',
    'cloudfront.net', 'vercel.app', 'netlify.app', 'pages.dev', 'workers.dev', 'web.app',
    'firebaseapp.com', 'notion.site', 'readthedocs.io',
  ]);
  const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;

  function hostOf(input) {
    const s = String(input || '').trim();
    if (!s) return '';
    try {
      const u = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(s) ? s : `http://${s}`);
      return u.hostname.toLowerCase().replace(/\.$/, '');
    } catch (e) {
      return s.split('/')[0].toLowerCase();
    }
  }

  function siteKey(input) {
    const host = hostOf(input);
    if (!host || host === 'localhost' || IPV4.test(host) || host.includes(':')) return host;
    const parts = host.split('.');
    if (parts.length <= 2) return host;
    const suffix = MULTI.has(parts.slice(-2).join('.')) ? 3 : 2;
    return parts.slice(-Math.min(suffix, parts.length)).join('.');
  }

  function sameSite(a, b) {
    const ka = siteKey(a);
    return !!ka && ka === siteKey(b);
  }

  globalThis.RDSite = { hostOf, siteKey, sameSite };
})();
