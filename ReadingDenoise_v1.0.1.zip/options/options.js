const FIELDS = {
  'grid-base': [
    { path: 'base', label: '基础分值（每字符默认）', step: 0.5 },
    { path: 'dict.stopword', label: '停用词库命中', step: 0.5 },
    { path: 'dict.contentword', label: '实体词库命中', step: 0.5 },
    { path: 'digit', label: '阿拉伯数字', step: 0.5 },
  ],
  'grid-posPrecise': [
    { path: 'posPrecise.punct', label: '标点符号', step: 0.5 },
    { path: 'posPrecise.func', label: '助词/介词/连词', step: 0.5 },
    { path: 'posPrecise.pronominal', label: '副词/代词/方位词', step: 0.5 },
    { path: 'posPrecise.zero', label: '拟声/非语素/数词/量词', step: 0.5 },
    { path: 'posPrecise.verbal', label: '动词/形容词', step: 0.5 },
    { path: 'posPrecise.link', label: '系动词/轻动词（是/在于/使/可以等）', step: 0.5 },
    { path: 'posPrecise.negation', label: '否定词（不/没/并非/避免/禁止等）', step: 0.5 },
    { path: 'posPrecise.nominal', label: '名词/时间词/处所词/名动词/名形词', step: 0.5 },
    { path: 'posPrecise.proper', label: '实体词（人名/地名/机构/时间/专名/作品名）', step: 0.5 },
    { path: 'posPrecise.oov', label: '新词/未登录词', step: 0.5 },
  ],
  'grid-tfidf': [
    { path: 'tfidf.quantilesFull', label: '完整映射分位数', array: true, hint: '把全页实词按 TF-IDF 从高到低排，这 4 个数是切线（位置占比），高于第 1 条切线的词拿第 1 个分值' },
    { path: 'tfidf.scoresFull', label: '完整映射分值', array: true, hint: '4 条切线从高到低对应的加减分，最后一个是最低档' },
    { path: 'tfidf.quantilesSmall', label: '小样本分位数', array: true, hint: '页面文本块太少时只用 2 条切线：高于第 1 条提分、低于第 2 条压分' },
    { path: 'tfidf.scoresSmall', label: '小样本修正', array: true },
    { path: 'tfidf.minBlocksAny', label: '启用 TF-IDF 最少文本块数', step: 1, int: true },
    { path: 'tfidf.minBlocksFull', label: '完整映射最少文本块数', step: 1, int: true },
  ],
  'grid-structure': [
    { path: 'structure.edgeSentence', label: '段落首句与尾句', step: 0.5 },
    { path: 'structure.fullWrap', label: '引号/括号完整包裹', step: 0.5 },
    { path: 'structure.halfWrap', label: '单侧引号/括号', step: 0.5 },
    { path: 'structure.dash', label: '破折号引出内容', step: 0.5 },
  ],
  'grid-fade': [
    { path: 'fade.ratioLight', label: '轻挡虚化比例', step: 0.01, min: 0, max: 1 },
    { path: 'fade.ratioStrong', label: '极强挡虚化比例', step: 0.01, min: 0, max: 1 },
    { path: 'fade.skewThreshold', label: '词频均值-中位数差值的阈值', step: 0.05 },
    { path: 'fade.skewAdjust', label: '词频均值-中位数差值的修正', step: 0.01, hint: '低分尾巴长（噪音多）加、高分尾巴长减' },
    { path: 'fade.snapWindow', label: '切割点谷底吸附窗口', step: 0.01, min: 0, max: 0.5, hint: '把虚化切割线移到得分分布的稀疏谷底，避免劈开同分字群；0=关闭' },
    { group: '曲线虚化（透明度随判断值渐变）' },
    { path: 'fade.opacityStrong', label: '极强挡最低透明度', step: 0.05, min: 0.05, max: 0.95 },
    { path: 'fade.opacityLight', label: '轻挡最低透明度', step: 0.05, min: 0.05, max: 0.95 },
    { group: '二元虚化' },
    { path: 'fade.binaryOpacity', label: '统一透明度', step: 0.05, min: 0.05, max: 0.95 },
  ],
};

let defaults = null;
let state = null;
let custom = { stop: [], content: [] };

// 流水线按固定下标读这四个数组（qs[0..3]/ss[0..4] 与 qs[0..1]/ss[0..2]），
// 长度或顺序错了会得到 undefined → 全页分数 NaN，所以在这里拦下
const ARRAY_RULES = {
  'tfidf.quantilesFull': { len: 4, quantile: true, label: '完整映射分位数' },
  'tfidf.scoresFull': { len: 5, label: '完整映射分值' },
  'tfidf.quantilesSmall': { len: 2, quantile: true, label: '小样本分位数' },
  'tfidf.scoresSmall': { len: 3, label: '小样本分值' },
};
const IMPORT_MAX_WORDS = 20000;
const IMPORT_MAX_BYTES = 2 * 1024 * 1024;

function validateArray(path, nums) {
  const rule = ARRAY_RULES[path];
  if (!rule) return nums.some((x) => !Number.isFinite(x)) ? '格式无效：请用逗号分隔的数字' : null;
  if (nums.some((x) => !Number.isFinite(x))) return '格式无效：请用逗号分隔的数字';
  if (nums.length !== rule.len) return `${rule.label}需要 ${rule.len} 个数字（当前 ${nums.length} 个），已还原`;
  if (rule.quantile) {
    if (nums.some((x) => x <= 0 || x > 1)) return `${rule.label}每项需在 0–1 之间，已还原`;
    for (let i = 1; i < nums.length; i++) if (nums[i] >= nums[i - 1]) return `${rule.label}需严格降序，已还原`;
  }
  return null;
}

function getPath(obj, path) {
  return path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj);
}
function setPath(obj, path, value) {
  const keys = path.split('.');
  let o = obj;
  for (let i = 0; i < keys.length - 1; i++) o = o[keys[i]];
  o[keys[keys.length - 1]] = value;
}
function deepMerge(base, over) {
  if (over === null || over === undefined) return base;
  if (typeof base !== 'object' || Array.isArray(base) || base === null) return over;
  if (typeof over !== 'object' || Array.isArray(over)) return over;
  const out = { ...base };
  for (const k of Object.keys(over)) out[k] = deepMerge(base[k], over[k]);
  return out;
}

let toastTimer = null;
function toast(text) {
  const el = document.getElementById('toast');
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1200);
}

let saveTimer = null;

// 只写调用方负责的字段，其余字段取写前最新存储，避免用打开页面时的旧快照覆盖别处（弹窗）的修改
let writeChain = Promise.resolve();
function writePatch(patch) {
  const run = async () => {
    const stored = await chrome.storage.local.get('rd-settings');
    const prev = stored['rd-settings'] || {};
    // popup 维护 mode/strength；历史 'fast' 归一化为 'precise'
    await chrome.storage.local.set({
      'rd-settings': {
        ...prev,
        mode: prev.mode === 'off' ? 'off' : 'precise',
        strength: prev.strength ?? defaults.strength,
        ...patch,
      },
    });
    toast('已保存');
  };
  // 串行写入，避免两次保存交错时各自基于旧快照互相覆盖
  writeChain = writeChain.then(run, run);
  return writeChain;
}

async function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    // 网站名单单独写入；mode/strength/fadeStyle 由弹窗维护，这里都不带
    const { mode, strength, fadeStyle, siteMode, sitelist, ...rest } = deepMerge(defaults, state);
    await writePatch(rest);
  }, 250);
}

function saveSitelist() {
  return writePatch({ sitelist: Array.isArray(state.sitelist) ? state.sitelist.slice() : [] });
}

function saveSiteMode() {
  return writePatch({ siteMode: state.siteMode === 'allow' ? 'allow' : 'block' });
}

function buildFields() {
  for (const [gridId, fields] of Object.entries(FIELDS)) {
    const grid = document.getElementById(gridId);
    grid.innerHTML = '';
    for (const f of fields) {
      if (f.group) {
        const h = document.createElement('div');
        h.className = 'group-title';
        h.textContent = f.group;
        grid.appendChild(h);
        continue;
      }
      const wrap = document.createElement('div');
      wrap.className = 'field';
      const label = document.createElement('label');
      label.textContent = f.label;
      const value = getPath(state, f.path);
      const def = getPath(defaults, f.path);
      const mark = () => {
        const mod = JSON.stringify(getPath(state, f.path)) !== JSON.stringify(def);
        wrap.classList.toggle('modified', mod);
        label.title = mod ? `默认值：${Array.isArray(def) ? def.join(', ') : def}` : '';
      };
      let input;
      if (f.array) {
        input = document.createElement('input');
        input.type = 'text';
        input.value = Array.isArray(value) ? value.join(', ') : value;
        input.addEventListener('change', () => {
          const nums = input.value.split(/[,，\s]+/).filter(Boolean).map(Number);
          const err = validateArray(f.path, nums);
          if (err) {
            input.value = getPath(state, f.path).join(', ');
            toast(err);
            return;
          }
          setPath(state, f.path, nums);
          mark();
          save();
        });
      } else {
        input = document.createElement('input');
        input.type = 'number';
        input.step = f.step ?? 0.5;
        if (f.min !== undefined) input.min = f.min;
        if (f.max !== undefined) input.max = f.max;
        input.value = value;
        input.addEventListener('change', () => {
          let v = parseFloat(input.value);
          if (!Number.isFinite(v)) { input.value = getPath(state, f.path); return; }
          if (f.int) v = Math.round(v);
          setPath(state, f.path, v);
          mark();
          save();
        });
      }
      mark();
      label.appendChild(input);
      wrap.appendChild(label);
      if (f.hint) {
        const hint = document.createElement('div');
        hint.className = 'hint';
        hint.textContent = f.hint;
        wrap.appendChild(hint);
      }
      grid.appendChild(wrap);
    }
  }
}

function renderWordList(kind) {
  const el = document.getElementById(`list-${kind}`);
  const words = custom[kind];
  const title = document.getElementById(`custom-${kind}-title`);
  if (title) title.textContent = `${kind === 'stop' ? '自定义停用词' : '自定义实体词'} · ${words.length}`;
  el.innerHTML = '';
  if (!words.length) {
    el.innerHTML = '<span class="empty">暂无自定义词条</span>';
    return;
  }
  for (const w of words) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = w;
    const btn = document.createElement('button');
    btn.textContent = '×';
    btn.title = '删除';
    btn.addEventListener('click', async () => {
      custom[kind] = custom[kind].filter((x) => x !== w);
      await chrome.storage.local.set({ 'rd-custom': custom });
      renderWordList(kind);
      toast('已删除');
    });
    chip.appendChild(btn);
    el.appendChild(chip);
  }
}

function parseWords(text) {
  return [...new Set(text.split(/[\r\n,，;；\t ]+/).map((x) => x.trim()).filter(Boolean))];
}

// ---------- 网站名单 ----------

function renderSiteSection() {
  const mode = state.siteMode === 'allow' ? 'allow' : 'block';
  document.getElementById('mode-block').classList.toggle('primary', mode === 'block');
  document.getElementById('mode-allow').classList.toggle('primary', mode === 'allow');
  const list = Array.isArray(state.sitelist) ? state.sitelist : [];
  const box = document.getElementById('site-list');
  box.innerHTML = '';
  if (!list.length) {
    box.innerHTML = '<span class="empty">名单为空</span>';
    return;
  }
  for (const u of list) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = u;
    const btn = document.createElement('button');
    btn.textContent = '×';
    btn.title = '移除';
    btn.addEventListener('click', () => {
      state.sitelist = (state.sitelist || []).filter((x) => x !== u);
      renderSiteSection();
      saveSitelist();
    });
    chip.appendChild(btn);
    box.appendChild(chip);
  }
}

document.getElementById('mode-block').addEventListener('click', () => {
  state.siteMode = 'block';
  renderSiteSection();
  saveSiteMode();
});
document.getElementById('mode-allow').addEventListener('click', () => {
  state.siteMode = 'allow';
  renderSiteSection();
  saveSiteMode();
});

async function addWords(kind, text) {
  const words = parseWords(text);
  if (!words.length) return;
  custom[kind] = [...new Set([...custom[kind], ...words])];
  await chrome.storage.local.set({ 'rd-custom': custom });
  renderWordList(kind);
  toast(`已添加 ${words.length} 个词条`);
}

function bindWords(kind) {
  const input = document.getElementById(`custom-${kind}-input`);
  document.getElementById(`add-${kind}`).addEventListener('click', async () => {
    await addWords(kind, input.value);
    input.value = '';
  });
  document.getElementById(`file-${kind}`).addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > IMPORT_MAX_BYTES) {
      toast('文件过大：仅支持 2MB 以内的 txt');
      e.target.value = '';
      return;
    }
    const text = await file.text();
    if (parseWords(text).length > IMPORT_MAX_WORDS) {
      toast(`单次导入最多 ${IMPORT_MAX_WORDS} 条，已取消`);
      e.target.value = '';
      return;
    }
    await addWords(kind, text);
    e.target.value = '';
  });
  document.getElementById(`clear-${kind}`).addEventListener('click', async () => {
    if (!custom[kind].length || !confirm(`确定清空全部自定义${kind === 'stop' ? '停用词' : '实体词'}？`)) return;
    custom[kind] = [];
    await chrome.storage.local.set({ 'rd-custom': custom });
    renderWordList(kind);
    toast('已清空');
  });
}

document.getElementById('reset-all').addEventListener('click', async () => {
  if (!confirm('确定恢复所有分数修正参数为默认值？（不影响自定义词条、网站名单与开关状态）')) return;
  // 只清高级参数：mode/strength/fadeStyle 由弹窗维护，网站名单也不属于分数参数
  const stored = await chrome.storage.local.get('rd-settings');
  const prev = stored['rd-settings'] || {};
  const { mode, strength, fadeStyle, siteMode, sitelist, ...defaultRest } = JSON.parse(JSON.stringify(defaults));
  await chrome.storage.local.set({
    'rd-settings': {
      ...prev,
      mode: prev.mode === 'off' ? 'off' : 'precise',
      strength: prev.strength ?? defaults.strength,
      ...defaultRest,
    },
  });
  state = JSON.parse(JSON.stringify(defaults));
  state.siteMode = prev.siteMode === 'allow' ? 'allow' : (siteMode || 'block');
  state.sitelist = Array.isArray(prev.sitelist) ? prev.sitelist : sitelist;
  buildFields();
  renderSiteSection();
  toast('已恢复默认');
});

// 弹窗也能改网站名单，这里跟随存储实时刷新，避免页面显示旧名单后再整体写回丢数据
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes['rd-settings'] || !state) return;
  const next = changes['rd-settings'].newValue || {};
  if (next.siteMode !== undefined) state.siteMode = next.siteMode === 'allow' ? 'allow' : 'block';
  if (Array.isArray(next.sitelist)) state.sitelist = next.sitelist;
  renderSiteSection();
});

(async function init() {
  const res = await fetch(chrome.runtime.getURL('worker/defaults.json'));
  defaults = await res.json();
  const stored = await chrome.storage.local.get(['rd-settings', 'rd-custom']);
  // 深拷贝默认值再合并，避免修改嵌套对象时污染 defaults（影响「恢复默认」与偏离标记）
  state = deepMerge(JSON.parse(JSON.stringify(defaults)), stored['rd-settings'] || {});
  custom = stored['rd-custom'] || { stop: [], content: [] };
  buildFields();
  renderSiteSection();
  renderWordList('stop');
  renderWordList('content');
  bindWords('stop');
  bindWords('content');
})();
