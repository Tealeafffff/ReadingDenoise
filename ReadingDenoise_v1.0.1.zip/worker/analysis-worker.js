// 分析 Worker 入口（module worker，运行在扩展源，不占用页面主线程）
import { Analyzer, DictMatcher } from './pipeline.js';
import { initLac, lacTag } from './lac.js';

let jieba = null; // 仅用作新词/未登录词判定（jieba.cut 切分对照）
let ort = null;
let lacReady = false;
let settings = null;
let analyzer = null;
let matchers = null;
let dictTexts = null; // {stop: string, content: string, english: string}
let initPromise = null;

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch failed: ${url}`);
  return res.text();
}

async function loadDicts() {
  if (dictTexts) return dictTexts;
  const base = new URL('../dicts/', import.meta.url);
  const [stop, content, english] = await Promise.all([
    fetchText(new URL('stopwords.txt', base)),
    fetchText(new URL('contentwords.txt', base)),
    fetchText(new URL('english-stopwords.txt', base)),
  ]);
  dictTexts = { stop, content, english };
  return dictTexts;
}

function buildMatchers(customStop, customContent) {
  const stop = new DictMatcher();
  const content = new DictMatcher();
  for (const w of dictTexts.stop.split('\n')) { const t = w.trim(); if (t) stop.add(t); }
  for (const w of dictTexts.content.split('\n')) { const t = w.trim(); if (t) content.add(t); }
  for (const w of dictTexts.english.split('\n')) { const t = w.trim(); if (t) stop.add(t); }
  for (const w of customStop || []) { const t = (w || '').trim(); if (t) stop.add(t); }
  for (const w of customContent || []) { const t = (w || '').trim(); if (t) content.add(t); }
  return { stop, content };
}

async function ensureJieba() {
  if (jieba) return jieba;
  const m = await import(new URL('../vendor/jieba-wasm/pkg/web/jieba_rs_wasm.js', import.meta.url).href);
  await m.default();
  jieba = m;
  return jieba;
}

async function ensureLac() {
  if (lacReady) return;
  ort = await import(new URL('../vendor/onnxruntime-web/dist/ort.wasm.min.mjs', import.meta.url).href);
  await initLac(ort);
  lacReady = true;
}

function makeTagger() {
  return async (text, offset) => {
    const toks = await lacTag(ort, text);
    for (const t of toks) { t.start += offset; t.end += offset; }
    return toks;
  };
}

async function buildAnalyzer() {
  await loadDicts();
  matchers = buildMatchers(settings.customStop, settings.customContent);
  await Promise.all([ensureJieba(), ensureLac()]);
  const tagger = makeTagger();
  const oovChecker = (word) => { try { return jieba.cut(word, true).length >= 2; } catch { return false; } };
  return new Analyzer(settings, tagger, matchers, oovChecker);
}

async function getAnalyzer() {
  if (!analyzer) {
    if (!initPromise) {
      initPromise = buildAnalyzer().then(
        (a) => { analyzer = a; initPromise = null; return a; },
        (err) => { initPromise = null; throw err; }, // 失败不缓存，允许下次消息重试
      );
    }
    return initPromise;
  }
  return analyzer;
}

function sendResults(results) {
  const CHUNK = 200;
  for (let i = 0; i < results.length; i += CHUNK) {
    const part = results.slice(i, i + CHUNK);
    const buffers = part.map((r) => r.scores.buffer);
    self.postMessage({ type: 'result', nodes: part, last: i + CHUNK >= results.length }, buffers);
  }
  if (results.length === 0) self.postMessage({ type: 'result', nodes: [], last: true });
}

console.info('[rd-worker] module loaded');

// 消息串行化：异步 handler 不能交错执行（score 必须等 submit 完成）
let queue = Promise.resolve();
self.onmessage = (e) => {
  queue = queue.then(() => handle(e.data)).catch((err) => {
    console.error('[rd-worker]', err);
    self.postMessage({ type: 'error', message: String((err && err.message) || err) });
  });
};

async function handle(msg) {
  try {
    if (msg.type === 'settings') {
      settings = msg.settings;
      if (msg.rebuild) { analyzer = null; }
      self.postMessage({ type: 'ready' });
    } else if (msg.type === 'reset') {
      analyzer = null;
      self.postMessage({ type: 'ready' });
    } else if (msg.type === 'submit') {
      const a = await getAnalyzer();
      const t0 = performance.now();
      await a.addBlocks(msg.blocks);
      const last = a.blocks[a.blocks.length - 1];
      const sample = last ? Array.from(last.scores.slice(0, 12)).join(',') : '';
      console.info('[rd-worker] submitted blocks:', a.blocks.length, `(${(performance.now() - t0).toFixed(0)}ms) sample scores:`, sample);
      self.postMessage({ type: 'submitted', batchId: msg.batchId, ms: performance.now() - t0 });
    } else if (msg.type === 'score') {
      const a = await getAnalyzer();
      const results = a.finalize(msg.nodeIds || null);
      console.info('[rd-worker] finalize results:', results.length);
      sendResults(results);
      self.postMessage({ type: 'done', blockCount: a.blocks.length });
    }
  } catch (err) {
    console.error('[rd-worker]', err);
    self.postMessage({ type: 'error', message: String((err && err.message) || err) });
  }
}
