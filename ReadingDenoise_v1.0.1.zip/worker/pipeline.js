// 评分流水线：词典匹配 -> 分词词性 -> 文段结构 -> TF-IDF -> 输出每字符分数

const GARBAGE_RE = /[\uFFFD\u0000-\u0008\u000B\u000C\u000E-\u001F\uE000-\uF8FF]/;
const PUNCT_CHAR_RE = /[\p{P}\p{S}]/u;
const SENT_END = '。！？!?；;…\n';
const SOFT_END = '，、：,:';

export function splitSentences(text, maxLen = 60) {
  const ranges = [];
  let start = 0;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    let isEnd = SENT_END.includes(ch);
    if (!isEnd && i - start + 1 >= maxLen) {
      // 超长强制切分：回退到本句内最近的软断点，避免从词中间劈开
      let j = i;
      while (j > start && !SOFT_END.includes(text[j])) j--;
      if (j > start) i = j;
      isEnd = true;
    }
    if (isEnd) {
      if (i > start) ranges.push([start, i]);
      // 跳过连续的句末符
      while (i + 1 < text.length && SENT_END.includes(text[i + 1])) i++;
      start = i + 1;
    }
  }
  if (start < text.length) ranges.push([start, text.length]);
  return ranges;
}

function structureSentences(text) {
  // 与 splitSentences 类似，但保留完整句子范围（不含句末符），用于首尾句修正
  const ranges = [];
  let start = 0;
  for (let i = 0; i < text.length; i++) {
    if (SENT_END.includes(text[i])) {
      let s = start, e = i;
      while (s < e && /\s/.test(text[s])) s++;
      while (e > s && /\s/.test(text[e - 1])) e--;
      if (e > s) ranges.push([s, e]);
      while (i + 1 < text.length && SENT_END.includes(text[i + 1])) i++;
      start = i + 1;
    }
  }
  let s = start, e = text.length;
  while (s < e && /\s/.test(text[s])) s++;
  while (e > s && /\s/.test(text[e - 1])) e--;
  if (e > s) ranges.push([s, e]);
  return ranges;
}

const OPENERS = { '"': '"', '“': '”', '‘': '’', "'": "'", '「': '」', '『': '』', '《': '》', '〈': '〉', '(': ')', '（': '）', '[': ']', '【': '】', '〝': '〞' };
const CLOSERS = { '"': '"', '”': '“', '’': '‘', "'": "'", '」': '「', '』': '『', '》': '《', '〉': '〈', ')': '(', '）': '（', ']': '[', '】': '【', '〞': '〝' };
const AMBIG = new Set(['"', "'"]);

function scanQuotes(text) {
  const pairs = [];
  const lones = [];
  const stack = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const isOpen = ch in OPENERS;
    const isClose = ch in CLOSERS;
    if (!isOpen && !isClose) continue;
    if (isOpen && (!AMBIG.has(ch) || stack.length === 0 || stack[stack.length - 1].ch !== ch)) {
      stack.push({ ch, i });
      continue;
    }
    // 作为闭符处理
    const want = CLOSERS[ch];
    let found = -1;
    for (let k = stack.length - 1; k >= 0; k--) {
      if (stack[k].ch === want) { found = k; break; }
    }
    if (found >= 0) {
      for (let k = found + 1; k < stack.length; k++) lones.push(stack[k].i);
      pairs.push([stack[found].i, i]);
      stack.length = found;
    } else if (isOpen && AMBIG.has(ch)) {
      stack.push({ ch, i });
    } else {
      lones.push(i);
    }
  }
  for (const s of stack) lones.push(s.i);
  return { pairs, lones };
}

const DASH_RE = /(——|――|──|—|–)/g;
const CONTENT_CATS = new Set(['nominal', 'verbal', 'proper', 'oov']);
const ENGLISH_WORD_RE = /^[A-Za-z]+$/;
const NOMINAL_SUFFIXES = new Set(['感', '性', '率', '量', '度']);
// 系动词/存在动词/轻动词信息量低，不参与实词片段合并，否则会把「是」「也是」「在于」抬到术语的高分
const LINK_VERBS = new Set(['有', '没有', '在', '为', '在于', '成为', '变成', '等于', '属于', '分为', '称为', '叫做', '使', '让', '令', '加', '可', '能', '会', '要', '可以', '能够', '应该', '必须', '需要', '须要', '进行', '加以', '予以', '给予', '作出', '当作', '视为', '看作', '当成', '称作', '像', '如同', '存在', '处于', '位于', '包括', '包含', '含有', '具有', '有着', '拥有', '将会', '可能']);
// 「可能会/应该会」会被 LAC 合成单 token，去掉「会」后在表内则同样按系动词处理
const isLinkVerb = (word) => LINK_VERBS.has(word) || (word.length <= 3 && word.endsWith('是')) || (word.length >= 3 && word.endsWith('会') && LINK_VERBS.has(word.slice(0, -1)));
// 否定词虚化后会反转句意（"不在于单一模型"），单独成类提分保持可见。
// 谱系参照现代汉语否定副词研究：不/没/别/莫/勿/未/非/无/甭/休/弗 + 模态否定（不必/无法/难以）+ 禁止类（禁止/严禁）
// 预防/阻止类与立场否定类动词同样带否定力（虚化"防止"后指令句意反转），且按普通动词处理时得分随上下文波动、常卡在轻/中挡阈值之间，一并收录。
const NEG_WORDS = new Set(['不', '没', '没有', '别', '莫', '未', '非', '勿', '毋', '无', '甭', '休', '弗', '并不', '不再', '不会', '不能', '不要', '不是', '从未', '绝不', '决不', '并非', '毫无', '无一', '并无', '绝无', '不必', '不宜', '不应', '不该', '不得', '不曾', '尚未', '未曾', '未尝', '无法', '没法', '无须', '无需', '毋庸', '不消', '未必', '免得', '禁止', '严禁', '难以', '无从', '何不', '岂不', '休想', '避免', '防止', '预防', '防范', '谨防', '提防', '严防', '杜绝', '阻止', '阻挡', '拒绝', '反对', '否认', '否定', '抵制', '制止', '遏止', '遏制', '阻拦', '切忌', '切勿', '请勿', '忌', '以防', '免受', '免于', '回避']);
const NEG_PREFIX = ['不', '没', '并', '莫', '别', '未'];
const MODAL_PREFIX = ['可', '应', '须', '宜', '需'];
// LAC 会把否定和动词切在一起（并没有/不属于/可避免），按"前缀 + 剩余部分"识别
function isNegation(word) {
  if (NEG_WORDS.has(word)) return true;
  // 可能/需要/应该 等模态词本身在 LINK_VERBS，不参与组合判定（没有 例外：NEG_WORDS 优先）
  if (LINK_VERBS.has(word)) return false;
  if (word.length < 2 || word.length > 4) return false;
  const rest = word.slice(1);
  if (NEG_PREFIX.includes(word[0])) return NEG_WORDS.has(rest) || LINK_VERBS.has(rest);
  // 模态 + 否定词（可避免/应防止）：剩余部分必须自带否定力，避免"需包含"误判
  if (MODAL_PREFIX.includes(word[0])) return NEG_WORDS.has(rest);
  return false;
}

export function preciseCategory(tag) {
  if (tag === 'w') return 'punct';
  if (tag === 'u' || tag === 'p' || tag === 'c') return 'func';
  if (tag === 'd' || tag === 'r' || tag === 'f') return 'pronominal';
  if (tag === 'm' || tag === 'q' || tag === 'xc' || tag === 'O') return 'zero';
  if (tag === 'PER' || tag === 'LOC' || tag === 'ORG' || tag === 'TIME' || tag === 'nz' || tag === 'nw') return 'proper';
  if (tag === 'v' || tag === 'vd' || tag === 'a' || tag === 'ad') return 'verbal';
  if (tag === 'n' || tag === 'vn' || tag === 'an' || tag === 't' || tag === 's') return 'nominal';
  return 'zero';
}

export class DictMatcher {
  constructor() {
    this.set = new Set();
    this.byFirst = new Map(); // char -> lengths(Set)
  }
  static key(word) { return ENGLISH_WORD_RE.test(word) ? word.toLowerCase() : word; }
  add(word) {
    if (!word) return;
    word = DictMatcher.key(word);
    if (this.set.has(word)) return;
    this.set.add(word);
    const first = word[0].toLowerCase();
    let lengths = this.byFirst.get(first);
    if (!lengths) { lengths = new Set(); this.byFirst.set(first, lengths); }
    lengths.add(word.length);
  }
  addAll(words) { for (const w of words) this.add(w); }
  has(word) { return this.set.has(DictMatcher.key(word)); }
  matchAt(text, i) {
    const first = text[i];
    if (!first || !this.byFirst.has(first.toLowerCase())) return 0;
    const lengths = this.byFirst.get(first.toLowerCase());
    const remaining = text.length - i;
    let best = 0;
    for (const L of lengths) {
      if (L > remaining || L <= best) continue;
      const part = text.substr(i, L);
      if (!this.set.has(DictMatcher.key(part))) continue;
      if (ENGLISH_WORD_RE.test(part)) {
        const before = i > 0 ? text[i - 1] : '';
        const after = i + L < text.length ? text[i + L] : '';
        if (/[A-Za-z0-9_]/.test(before) || /[A-Za-z0-9_]/.test(after)) continue;
      }
      best = L;
    }
    return best;
  }
}

function atomicRuns(text) {
  const spans = [];
  const urlRe = /(?:https?:\/\/|www\.)[^\s<>"'，。！？；：、（）【】《》“”‘’]+/gi;
  let m;
  while ((m = urlRe.exec(text)) !== null) {
    let end = m.index + m[0].length;
    while (end > m.index && /[)\]},.!?;:，。！？；：、…]/.test(text[end - 1])) end--;
    if (end - m.index > 4) spans.push([m.index, end]);
  }
  const alnumRe = /[A-Za-z0-9０-９]+/g;
  while ((m = alnumRe.exec(text)) !== null) {
    if (/[0-9０-９]/.test(m[0]) && /[A-Za-z]/.test(m[0])) spans.push([m.index, m.index + m[0].length]);
  }
  spans.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const merged = [];
  for (const [s, e] of spans) {
    const last = merged[merged.length - 1];
    if (last && s <= last[1]) last[1] = Math.max(last[1], e);
    else merged.push([s, e]);
  }
  return merged;
}

export class Analyzer {
  constructor(settings, tagger, matchers, oovChecker) {
    this.s = settings;
    this.tagger = tagger;
    this.stopM = matchers.stop;
    this.contentM = matchers.content;
    this.oovChecker = oovChecker;
    this.blocks = [];
    this.finalized = false;
    this.oovCache = new Map();
  }

  async addBlocks(blocks) {
    for (const b of blocks) {
      const rec = this._prepareBlock(b);
      if (rec) {
        await this._tokenizeBlock(rec);
        this._dictBlock(rec);
        this._structureBlock(rec);
        rec.preTfidf = rec.scores.slice();
        this.blocks.push(rec);
      }
    }
    this.finalized = false;
  }

  _prepareBlock(b) {
    let text = '';
    const nodeOffsets = [];
    for (const n of b.nodes) {
      nodeOffsets.push({ nodeId: n.nodeId, start: text.length, end: text.length + n.text.length });
      text += n.text;
    }
    if (!text.trim()) return null;
    const scores = new Float32Array(text.length).fill(this.s.base);
    const allHidden = b.nodes.length > 0 && b.nodes.every((n) => n.hidden);
    return {
      text,
      nodeOffsets,
      scores,
      wordOcc: new Map(),
      tokenCount: 0,
      singleTokenPos: new Set(), // 单字 token 的位置：单字词典命中只在这些位置生效
      contentRuns: [], // 相邻实词 token 组成的连续片段
      atomicRuns: atomicRuns(text), // URL 与连续英数：finalize 末尾统一覆盖
      allHidden,
    };
  }

  _repairTokens(tokens) {
    const source = tokens.map((t) => ({ ...t }));
    const repaired = [];
    for (let i = 0; i < source.length; i++) {
      const first = source[i];
      let merged = null;
      if (first.word === '在' && ['p', 'u'].includes(first.tag)) {
        const next = source[i + 1];
        if (next && next.start === first.end && ['v', 'vn'].includes(next.tag)) {
          merged = { word: first.word + next.word, tag: next.tag, start: first.start, end: next.end };
        }
      }
      if (!merged && ['v', 'vn'].includes(first.tag) && first.word.length <= 4) {
        const next = source[i + 1];
        if (next && next.start === first.end && next.word.length === 1 && NOMINAL_SUFFIXES.has(next.word)) {
          merged = { word: first.word + next.word, tag: 'vn', start: first.start, end: next.end };
        }
      }
      repaired.push(merged || first);
      if (merged) i++;
    }
    return repaired;
  }

  async _tokenizeBlock(rec) {
    const { text, scores } = rec;
    const posCfg = this.s.posPrecise;
    const categorize = preciseCategory;
    const sentences = splitSentences(text, 60);
    let runStart = -1;
    let runEnd = -1;
    const flushRun = () => {
      if (runStart >= 0 && runEnd - runStart > 1) rec.contentRuns.push([runStart, runEnd]);
      runStart = -1;
      runEnd = -1;
    };

    for (const [ss, se] of sentences) {
      const sub = text.slice(ss, se);
      let tokens;
      try {
        tokens = await this.tagger(sub, ss);
      } catch (e) {
        console.warn('[rd] tagger failed', e);
        continue;
      }
      tokens = this._repairTokens(tokens);
      for (let ti = 0; ti < tokens.length; ti++) {
        const tok = tokens[ti];
        if (!tok.word) continue;
        const end = Math.min(tok.end, text.length);
        if (end - tok.start === 1) rec.singleTokenPos.add(tok.start);
        let cat = categorize(tok.tag, tok.word);
        if (tok.word.length === 1 && GARBAGE_RE.test(tok.word)) cat = 'zero';
        // 英文停用词优先于 LAC 词性，避免句首 The 被标成 PER 后重新亮起
        else if (ENGLISH_WORD_RE.test(tok.word) && this.stopM.has(tok.word)) cat = 'func';
        // LAC 把「无论」拆成 无/c 论/c：单独成词的否定字「无」会亮出来，按连词统一压暗
        else if (tok.word === '无' && tokens[ti + 1] && tokens[ti + 1].word === '论') cat = 'func';
        else if (isNegation(tok.word)) cat = 'negation';
        else if (cat === 'verbal' && isLinkVerb(tok.word)) cat = 'link';
        // OOV 加分只给"词典没有、jieba 也切不开"的新词；已收录词不该拿这个加分
        if (this.oovChecker && (cat === 'nominal' || cat === 'verbal') && tok.word.length >= 2
          && !this.stopM.set.has(tok.word) && !this.contentM.set.has(tok.word)) {
          let isOov = this.oovCache.get(tok.word);
          if (isOov === undefined) { isOov = this.oovChecker(tok.word); this.oovCache.set(tok.word, isOov); }
          if (isOov) cat = 'oov';
        }
        if (CONTENT_CATS.has(cat)) {
          if (runStart < 0) { runStart = tok.start; runEnd = end; }
          else if (tok.start === runEnd) { runEnd = end; }
          else { flushRun(); runStart = tok.start; runEnd = end; }
        } else {
          flushRun();
        }
        if (cat !== 'punct') {
          const delta = posCfg[cat] ?? 0;
          if (delta !== 0) {
            for (let k = tok.start; k < end; k++) scores[k] += delta;
          }
        }
        // TF-IDF 只统计实词侧 token：虚词/代副词/数量词参与会被高频抬分，抵消词典与词性惩罚
        if (CONTENT_CATS.has(cat) && tok.word.trim() && end > tok.start) {
          rec.tokenCount++;
          let occ = rec.wordOcc.get(tok.word);
          if (!occ) { occ = []; rec.wordOcc.set(tok.word, occ); }
          occ.push([tok.start, end]);
        }
      }
      flushRun();
    }

    // 字符级标点修正：句末标点不在分词范围内，统一在此处理
    const punctDelta = posCfg.punct ?? 0;
    const isDigitAt = (i) => {
      const c = text.charCodeAt(i);
      return (c >= 0x30 && c <= 0x39) || (c >= 0xff10 && c <= 0xff19);
    };
    // 小数点/版本号里的点（两侧都是数字）属于数字的一部分，不按标点扣分
    const isNumDot = (i) => (text[i] === '.' || text[i] === '．') && i > 0 && i + 1 < text.length && isDigitAt(i - 1) && isDigitAt(i + 1);
    if (punctDelta !== 0) {
      for (let i = 0; i < text.length; i++) {
        if (PUNCT_CHAR_RE.test(text[i]) && !isNumDot(i)) scores[i] += punctDelta;
      }
    }

    // 字符级数字修正：LAC 把「2024年」混标成数词/时间词，中文数字同为 m，按 token 走会误伤
    const digitDelta = this.s.digit ?? 0;
    if (digitDelta !== 0) {
      for (let i = 0; i < text.length; i++) {
        if (isDigitAt(i) || isNumDot(i)) scores[i] += digitDelta;
      }
    }
  }

  // 词典匹配：两边都取最长再比较，同长实词优先；
  // 单字命中只在该字自成 token 时生效，否则会在多字词内部打孔（智能的「能」、事故的「故」）
  _dictBlock(rec) {
    const { text, scores, singleTokenPos } = rec;
    const cM = this.contentM, sM = this.stopM;
    const cd = this.s.dict.contentword, sd = this.s.dict.stopword;
    let i = 0;
    while (i < text.length) {
      let cLen = cM.matchAt(text, i);
      let sLen = sM.matchAt(text, i);
      if (cLen === 1 && !singleTokenPos.has(i)) cLen = 0;
      if (sLen === 1 && !singleTokenPos.has(i)) sLen = 0;
      const len = cLen > sLen ? cLen : sLen;
      if (len > 0) {
        const d = cLen >= sLen ? cd : sd;
        for (let k = i; k < i + len; k++) scores[k] += d;
        i += len;
      } else i++;
    }
  }

  _structureBlock(rec) {
    const { text, scores } = rec;
    const cfg = this.s.structure;
    const apply = (s, e, d) => { for (let k = s; k < e && k < scores.length; k++) scores[k] += d; };

    // 首句与尾句
    if (cfg.edgeSentence !== 0) {
      const sents = structureSentences(text);
      if (sents.length > 0) {
        const first = sents[0];
        apply(first[0], first[1], cfg.edgeSentence);
        if (sents.length > 1) {
          const last = sents[sents.length - 1];
          apply(last[0], last[1], cfg.edgeSentence);
        }
      }
    }

    // 引号/括号包裹
    if (cfg.fullWrap !== 0 || cfg.halfWrap !== 0) {
      const { pairs, lones } = scanQuotes(text);
      const tokens = [];
      for (const occ of rec.wordOcc.values()) for (const [s, e] of occ) tokens.push([s, e]);
      if (cfg.fullWrap !== 0) {
        for (const [os, oe] of pairs) {
          for (const [s, e] of tokens) {
            if (s > os && e <= oe) apply(s, e, cfg.fullWrap);
          }
        }
      }
      if (cfg.halfWrap !== 0 && lones.length) {
        const loneSet = new Set(lones);
        for (const [s, e] of tokens) {
          let hit = false;
          if (loneSet.has(s - 1) || loneSet.has(e) || (e - s <= 8 && Array.from(loneSet).some((x) => x > s && x < e))) hit = true;
          if (hit) apply(s, e, cfg.halfWrap);
        }
      }
    }

    // 破折号引出的内容
    if (cfg.dash !== 0) {
      DASH_RE.lastIndex = 0;
      let m;
      while ((m = DASH_RE.exec(text)) !== null) {
        let end = m.index + m[0].length;
        let stop = end;
        while (stop < text.length && !'。！？!?\n'.includes(text[stop])) stop++;
        if (stop > end && stop - end <= 120) apply(end, stop, cfg.dash);
      }
    }
  }

  finalize(newNodeIds) {
    // TF-IDF + 片段统一 + 导出分数
    const cfg = this.s.tfidf;
    // 每次都从 TF-IDF 之前的基准重算：增量提交后新旧块的 df 口径保持一致
    for (const b of this.blocks) b.scores.set(b.preTfidf);
    // 整块隐藏的文本不参与 df 与块数统计，避免拉偏可见内容的阈值
    const visible = this.blocks.filter((b) => !b.allHidden);
    const N = visible.length;
    if (N >= cfg.minBlocksAny) {
      const df = new Map();
      for (const b of visible) {
        for (const w of b.wordOcc.keys()) df.set(w, (df.get(w) || 0) + 1);
      }
      const full = N >= cfg.minBlocksFull;
      const occ = [];
      const wordTfidf = new Map(); // block -> Map word -> value
      for (const b of this.blocks) {
        const m = new Map();
        wordTfidf.set(b, m);
        const total = Math.max(1, b.tokenCount);
        for (const [w, spans] of b.wordOcc) {
          const tf = spans.length / total;
          const idf = Math.log((N + 1) / ((df.get(w) || 0) + 0.5));
          const v = tf * idf;
          m.set(w, v);
          if (!b.allHidden) for (let k = 0; k < spans.length; k++) occ.push(v);
        }
      }
      if (occ.length > 0) {
        occ.sort((a, b) => a - b);
        const q = (p) => occ[Math.min(occ.length - 1, Math.max(0, Math.round(p * (occ.length - 1))))];
        let deltaOf;
        if (full) {
          const qs = cfg.quantilesFull.map(q);
          const ss = cfg.scoresFull;
          deltaOf = (v) => (v >= qs[0] ? ss[0] : v >= qs[1] ? ss[1] : v >= qs[2] ? ss[2] : v >= qs[3] ? ss[3] : ss[4]);
        } else {
          const qs = cfg.quantilesSmall.map(q);
          const ss = cfg.scoresSmall;
          deltaOf = (v) => (v >= qs[0] ? ss[0] : v <= qs[1] ? ss[2] : ss[1]);
        }
        for (const b of this.blocks) {
          const m = wordTfidf.get(b);
          for (const [w, v] of m) {
            const d = deltaOf(v);
            if (d === 0) continue;
            for (const [s, e] of b.wordOcc.get(w)) {
              // 标点不参与 TF-IDF：内容 token 里夹带的符号（DeepSeek-R1 的 -、2% 的 %）不吃加减分
              for (let k = s; k < e; k++) if (!PUNCT_CHAR_RE.test(b.text[k])) b.scores[k] += d;
            }
          }
        }
      }
    }

    // 术语连贯：相邻实词 token 组成的片段内部统一取最高分，
    // 避免「语言大模型」「学习框架」被 token 边界切成不同透明度
    for (const b of this.blocks) {
      for (const [s, e] of b.contentRuns) {
        let top = b.scores[s];
        for (let k = s + 1; k < e; k++) if (b.scores[k] > top) top = b.scores[k];
        for (let k = s; k < e; k++) b.scores[k] = top;
      }
    }

    // URL 与连续英数必须是不可分割的整体，避免标点、词性或词典在内部制造透明度差异
    for (const b of this.blocks) {
      for (const [s, e] of b.atomicRuns) {
        const hasDigit = /[0-9０-９]/.test(b.text.slice(s, e));
        let top = this.s.base + this.s.posPrecise.proper + (hasDigit ? this.s.digit : 0);
        for (let k = s; k < e; k++) if (b.scores[k] > top) top = b.scores[k];
        for (let k = s; k < e; k++) b.scores[k] = top;
      }
    }

    // 导出
    const wanted = newNodeIds ? new Set(newNodeIds) : null;
    const out = [];
    for (const b of this.blocks) {
      for (const no of b.nodeOffsets) {
        if (wanted && !wanted.has(no.nodeId)) continue;
        out.push({ nodeId: no.nodeId, scores: b.scores.slice(no.start, no.end) });
      }
    }
    this.finalized = true;
    return out;
  }
}
