// LAC ONNX 推理：字符词表映射 -> encoder -> Viterbi -> BIO 解码
// 移植自 kniost/LAC-ONNX 的参考实现 (lac.py)

let session = null;
let vocab = null; // char -> id
let oovId = 0;
let id2tag = null; // id -> tag string (后出现的 id 覆盖先前，与参考实现一致)
let q2b = null; // 全角/繁体 -> 半角/简体
let transitions = null; // Float32Array rows*cols
let tRows = 0;
let tCols = 0;

async function fetchBuf(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch failed: ${url} ${res.status}`);
  return res.arrayBuffer();
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch failed: ${url} ${res.status}`);
  return res.text();
}

function parseTsv(text) {
  const out = [];
  for (const line of text.split('\n')) {
    const t = line.indexOf('\t');
    if (t < 0) continue;
    out.push([line.slice(0, t), line.slice(t + 1).replace(/\r$/, '')]);
  }
  return out;
}

export async function initLac(ort) {
  if (session) return;
  const base = new URL('../models/', import.meta.url);

  const [modelBuf, transBuf, transMeta, wordText, tagText, q2bText] = await Promise.all([
    fetchBuf(new URL('lac_encoder.onnx', base)),
    fetchBuf(new URL('lac_crf_transitions.bin', base)),
    fetchText(new URL('lac_crf_transitions.json', base)),
    fetchText(new URL('word.dic', base)),
    fetchText(new URL('tag.dic', base)),
    fetchText(new URL('q2b.dic', base)),
  ]);

  vocab = new Map();
  for (const [k, v] of parseTsv(wordText)) vocab.set(v, parseInt(k, 10));
  oovId = vocab.get('OOV') ?? 0;

  id2tag = new Map();
  for (const [k, v] of parseTsv(tagText)) id2tag.set(parseInt(k, 10), v);

  q2b = new Map();
  for (const [k, v] of parseTsv(q2bText)) q2b.set(k, v);

  const meta = JSON.parse(transMeta);
  tRows = meta.rows;
  tCols = meta.cols;
  transitions = new Float32Array(transBuf);

  ort.env.wasm.wasmPaths = new URL('../vendor/onnxruntime-web/dist/', import.meta.url).href;
  ort.env.wasm.numThreads = 1;
  ort.env.wasm.proxy = false;
  ort.env.logLevel = 'error';

  session = await ort.InferenceSession.create(modelBuf, {
    executionProviders: ['wasm'],
    graphOptimizationLevel: 'all',
  });
}

const MAX_SENT_LEN = 96;

function viterbiDecode(emissions, seqLen, nTags) {
  // emissions: Float32Array (seqLen * nTags)
  let dp = emissions.slice(0, nTags);
  const backpointers = [];
  const scores = new Float32Array(nTags * nTags);
  for (let t = 1; t < seqLen; t++) {
    // scores[i*nTags+j] = dp[i] + T[i*nTags+j]
    for (let i = 0; i < nTags; i++) {
      const dpi = dp[i];
      const row = i * nTags;
      for (let j = 0; j < nTags; j++) scores[row + j] = dpi + transitions[row + j];
    }
    const bp = new Uint8Array(nTags);
    const ndp = new Float32Array(nTags);
    for (let j = 0; j < nTags; j++) {
      let best = -Infinity;
      let arg = 0;
      for (let i = 0; i < nTags; i++) {
        const s = scores[i * nTags + j];
        if (s > best) { best = s; arg = i; }
      }
      bp[j] = arg;
      ndp[j] = best + emissions[t * nTags + j];
    }
    dp = ndp;
    backpointers.push(bp);
  }
  let best = 0;
  for (let j = 1; j < nTags; j++) if (dp[j] > dp[best]) best = j;
  const path = new Array(seqLen);
  path[seqLen - 1] = best;
  for (let t = seqLen - 1; t >= 1; t--) {
    path[t - 1] = backpointers[t - 1][path[t]];
  }
  return path;
}

function decodeBio(chars, tagIds) {
  const results = [];
  let i = 0;
  while (i < chars.length) {
    const rawTag = id2tag.get(tagIds[i]) ?? 'n-B';
    const dash = rawTag.lastIndexOf('-');
    const label = dash > 0 ? rawTag.slice(0, dash) : rawTag;
    let end = i + 1;
    while (end < chars.length) {
      const t = id2tag.get(tagIds[end]) ?? 'n-B';
      if (t.endsWith('-I')) end++;
      else break;
    }
    results.push({ word: chars.slice(i, end).join(''), tag: label, start: i, end });
    i = end;
  }
  return results;
}

export async function lacTag(ort, text) {
  // 按句子与长度上限切分，逐段推理，返回 [{word, tag, start, end}]（相对 text 的偏移）
  const chars = Array.from(text);
  if (chars.length === 0) return [];
  const segments = [];
  let segStart = 0;
  const isBreak = (c) => '。！？；!?;\n'.includes(c);
  for (let i = 0; i < chars.length; i++) {
    if (isBreak(chars[i]) || i - segStart + 1 >= MAX_SENT_LEN) {
      if (i >= segStart) segments.push([segStart, i + 1]);
      segStart = i + 1;
    }
  }
  if (segStart < chars.length) segments.push([segStart, chars.length]);

  const out = [];
  for (const [s, e] of segments) {
    const segChars = chars.slice(s, e);
    const ids = new BigInt64Array(segChars.length);
    for (let i = 0; i < segChars.length; i++) {
      const c = q2b.get(segChars[i]) ?? segChars[i];
      ids[i] = BigInt(vocab.get(c) ?? oovId);
    }
    const feeds = {
      token_ids: new ort.Tensor('int64', ids, [1, segChars.length]),
      length: new ort.Tensor('int64', BigInt64Array.from([BigInt(segChars.length)]), [1]),
    };
    const results = await session.run(feeds);
    const outputName = session.outputNames[0];
    const logits = results[outputName].data; // (1, seq, nTags)
    const path = viterbiDecode(logits, segChars.length, tCols);
    for (const tok of decodeBio(segChars, path)) {
      out.push({ word: tok.word, tag: tok.tag, start: tok.start + s, end: tok.end + s });
    }
  }
  return out;
}
