// 后台：根据开关状态切换扩展图标（运行=彩色，关闭=灰色）
const ICONS = {
  on: { 16: 'icons/icon16.png', 48: 'icons/icon48.png', 128: 'icons/icon128.png' },
  off: { 16: 'icons/icon16-off.png', 48: 'icons/icon48-off.png', 128: 'icons/icon128-off.png' },
};

async function refreshIcon() {
  const stored = await chrome.storage.local.get('rd-settings');
  const mode = (stored['rd-settings'] && stored['rd-settings'].mode) || 'precise';
  const on = mode !== 'off';
  await chrome.action.setIcon({ path: on ? ICONS.on : ICONS.off });
  await chrome.action.setTitle({ title: on ? '阅读降噪：运行中' : '阅读降噪：已关闭' });
}

chrome.runtime.onInstalled.addListener(refreshIcon);
chrome.runtime.onStartup.addListener(refreshIcon);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes['rd-settings']) refreshIcon();
});
refreshIcon();
