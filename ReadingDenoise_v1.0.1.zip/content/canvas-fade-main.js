// canvas 虚化（MAIN 世界补丁）：拦截 fillText，暂缓文字绘制；
// 等隔离世界的 content.js 传来"每字透明度 + 坐标"后，再按字重画。
// 重绘：首次画字前留存画布背景快照；挡位/样式变化后，用快照清掉旧文字、按新透明度重画。
// 只在注入到 pdf.js 系查看器页面的帧里运行（manifest 限定 readest）。
(() => {
  if (window.__rdCanvasPatch) return;
  window.__rdCanvasPatch = true;
  document.documentElement.dataset.rdCanvas = '1';

  const proto = CanvasRenderingContext2D.prototype;
  const origFillText = proto.fillText;
  const origClearRect = proto.clearRect;
  // 画布可能被"收养"到别的帧显示（readest: 顶层绘制 → iframe 里展示），
  // 因此 id 加帧前缀保证跨帧唯一；坐标一律用"画布局部 CSS 坐标"，跨帧可比
  const FRAME_ID = Math.random().toString(36).slice(2, 8);
  let seq = 0;
  const queues = new Map(); // canvasId -> items[]
  const maps = new Map();   // canvasId -> { ops, pts }
  const queueTs = new Map(); // canvasId -> 首次入队时间（兜底计时）
  const idCanvas = new Map(); // canvasId -> canvas
  const states = new WeakMap(); // canvas -> { bg, bw, bh, items }
  const stats = { draws: 0, flushed: 0, faded: 0, fallbacks: 0, mismatches: 0, positionMapped: 0, redraws: 0 };
  window.__rdCanvasStats = stats;
  let lastNeed = 0;
  let disabled = false;

  const matOf = (m) => (m ? [m.a, m.b, m.c, m.d, m.e, m.f] : null);

  function invalidateCanvas(canvas) {
    const id = canvas.dataset.rdCanvasId;
    if (id) { queues.set(id, []); queueTs.delete(id); }
    const st = states.get(canvas);
    if (st) { st.bg = null; st.bw = 0; st.bh = 0; st.items = []; }
  }

  if (typeof HTMLCanvasElement !== 'undefined') {
    const canvasProto = HTMLCanvasElement.prototype;
    for (const prop of ['width', 'height']) {
      const descriptor = Object.getOwnPropertyDescriptor(canvasProto, prop);
      if (!descriptor || !descriptor.set) continue;
      Object.defineProperty(canvasProto, prop, {
        ...descriptor,
        set(value) { invalidateCanvas(this); descriptor.set.call(this, value); },
      });
    }
  }

  function requestMap() {
    const now = Date.now();
    if (now - lastNeed < 1500) return;
    lastNeed = now;
    window.postMessage({ __rd: 'canvas-need' }, '*');
  }

  function cssPointOf(item) {
    const canvas = item.canvas;
    const r = canvas.getBoundingClientRect();
    const m = item.m || [1, 0, 0, 1, 0, 0];
    const dx = m[0] * item.x + m[2] * item.y + m[4];
    const dy = m[1] * item.x + m[3] * item.y + m[5];
    const sx = canvas.width ? r.width / canvas.width : 1;
    const sy = canvas.height ? r.height / canvas.height : 1;
    return [dx * sx, dy * sy];
  }

  function draw(item, op) {
    const c = item.ctx;
    c.save();
    try {
      if (item.m) c.setTransform(item.m[0], item.m[1], item.m[2], item.m[3], item.m[4], item.m[5]);
      c.font = item.font;
      c.fillStyle = item.fill;
      c.textAlign = item.align;
      c.textBaseline = item.baseline;
      c.globalAlpha = item.alpha * op;
      origFillText.call(c, item.text, item.x, item.y);
      stats.flushed++;
      if (op < 1) stats.faded++;
    } finally {
      c.restore();
    }
  }

  function buildGetOp(items, map) {
    if (!map) return null;
    if (items.length === map.ops.length) return (i) => map.ops[i];
    if (map.pts && map.pts.length === map.ops.length) {
      stats.positionMapped++;
      const TOL2 = 14 * 14;
      return (i, item) => {
        const p = cssPointOf(item);
        let bd = Infinity;
        let bv = 1;
        for (let k = 0; k < map.pts.length; k++) {
          const dx = map.pts[k][0] - p[0];
          const dy = map.pts[k][1] - p[1];
          const d = dx * dx + dy * dy;
          if (d < bd) { bd = d; bv = map.ops[k]; }
        }
        return bd <= TOL2 ? bv : 1;
      };
    }
    stats.mismatches++;
    return (i) => (i < map.ops.length ? map.ops[i] : 1);
  }

  function ensureBg(canvas) {
    let st = states.get(canvas);
    if (!st) { st = { bg: null, bw: 0, bh: 0, items: [] }; states.set(canvas, st); }
    // 尺寸变化时画布会被自动清空，需要重拍背景
    if (!st.bg || st.bw !== canvas.width || st.bh !== canvas.height) {
      const bg = document.createElement('canvas');
      bg.width = canvas.width;
      bg.height = canvas.height;
      bg.getContext('2d').drawImage(canvas, 0, 0);
      st.bg = bg;
      st.bw = canvas.width;
      st.bh = canvas.height;
      st.items = [];
    }
    return st;
  }

  function queuedItems(canvasId) {
    const canvas = idCanvas.get(canvasId);
    const q = queues.get(canvasId) || [];
    return canvas ? q.filter((item) => item.w === canvas.width && item.h === canvas.height) : [];
  }

  function flush(canvasId) {
    const q = queuedItems(canvasId);
    queues.set(canvasId, []);
    queueTs.delete(canvasId);
    if (!q.length) return;
    const st = ensureBg(q[0].canvas);
    st.items.push(...q);
    if (maps.has(canvasId)) redraw(canvasId);
    else {
      stats.fallbacks++;
      for (const item of q) draw(item, 1);
    }
  }

  function redraw(canvasId, forceNormal = false) {
    const canvas = idCanvas.get(canvasId);
    const map = maps.get(canvasId);
    if (!canvas || (!forceNormal && !map)) return;
    const st = states.get(canvas);
    if (!st) return;
    if (st.bw !== canvas.width || st.bh !== canvas.height) { ensureBg(canvas); return; }
    if (!st.bg || !st.items.length) return;
    const bg = st.bg;
    const ctx = canvas.getContext('2d');
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    // 必须用原始 clearRect：补丁版会作废背景快照
    origClearRect.call(ctx, 0, 0, canvas.width, canvas.height);
    ctx.drawImage(bg, 0, 0);
    ctx.restore();
    const getOp = forceNormal ? null : buildGetOp(st.items, map);
    for (let i = 0; i < st.items.length; i++) draw(st.items[i], getOp ? getOp(i, st.items[i]) : 1);
    stats.redraws++;
  }

  // 周期兜底：映射迟迟不来（或该画布本就没有文字层）也要把字画出来
  setInterval(() => {
    const now = Date.now();
    let mustRequest = false;
    for (const [id, q] of queues) {
      if (!q.length) continue;
      if (maps.has(id)) continue;
      mustRequest = true;
      const ts = queueTs.get(id) || now;
      if (!queueTs.has(id)) queueTs.set(id, now);
      if (now - ts > 4000) flush(id);
    }
    if (mustRequest) requestMap();
  }, 1500);

  proto.fillText = function (text, x, y, maxWidth) {
    const s = text == null ? '' : String(text);
    if (!s || !s.trim()) return origFillText.call(this, text, x, y, maxWidth);
    const canvas = this.canvas;
    if (!canvas || disabled) {
      if (canvas) invalidateCanvas(canvas);
      return origFillText.call(this, text, x, y, maxWidth);
    }
    let id = canvas.dataset.rdCanvasId;
    if (!id) {
      id = FRAME_ID + '-' + (++seq);
      canvas.dataset.rdCanvasId = id;
      idCanvas.set(id, canvas);
    }
    const item = {
      ctx: this, canvas, text: s, x, y,
      w: canvas.width, h: canvas.height,
      font: this.font, fill: this.fillStyle, alpha: this.globalAlpha,
      align: this.textAlign, baseline: this.textBaseline,
      m: matOf(this.getTransform ? this.getTransform() : null),
    };
    stats.draws++;
    const q = queues.get(id) || [];
    q.push(item);
    queues.set(id, q);
    if (maps.has(id)) {
      queueMicrotask(() => flush(id));
    } else {
      if (!queueTs.has(id)) queueTs.set(id, Date.now());
      requestMap();
    }
  };

  // 查看器清屏（重绘前）时作废背景快照，下次画字时重拍
  proto.clearRect = function (x, y, w, h) {
    const canvas = this.canvas;
    if (canvas) invalidateCanvas(canvas);
    return origClearRect.call(this, x, y, w, h);
  };

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (d && d.__rd === 'canvas-mode') {
      disabled = !d.enabled;
      if (disabled) {
        for (const id of Array.from(queues.keys())) {
          const q = queuedItems(id);
          queues.set(id, []);
          queueTs.delete(id);
          if (!q.length) continue;
          const canvas = idCanvas.get(id);
          const st = canvas && ensureBg(canvas);
          if (st) st.items.push(...q);
        }
        for (const id of Array.from(idCanvas.keys())) redraw(id, true);
      } else {
        for (const id of Array.from(maps.keys())) redraw(id);
      }
      return;
    }
    if (!d || d.__rd !== 'canvas-map' || !d.canvasId || disabled) return;
    maps.set(d.canvasId, { ops: d.ops || [], pts: d.pts || null });
    const q = queues.get(d.canvasId);
    if (q && q.length) flush(d.canvasId);
    else redraw(d.canvasId);
  });
})();
