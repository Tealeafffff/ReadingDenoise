// 阅读降噪 content script：DOM 文本提取 -> worker 分析 -> 透明度渲染
(() => {
  'use strict';

  // 列表正文按正文处理（文章要点常以列表呈现）；行内强调/代码是作者标记，保持原样不参与评分
  // 视频播放器的弹幕/字幕是叠加层，随时间轴闪现，评分与虚化只会干扰观看
  const SKIP_SELECTOR = [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'a',
    'code', 'pre', 'kbd', 'samp', 'var',
    'nav', 'footer', 'header', 'aside',
    'strong', 'b', 'em', 'i', 'u', 's', 'mark', 'small', 'sub', 'sup',
    'button', 'input', 'textarea', 'select', 'option', 'label', 'form',
    'script', 'style', 'noscript', 'svg', 'iframe', 'canvas', 'video', 'audio', 'object', 'template',
    'figcaption', 'th', 'caption', 'summary',
    '.bpx-player-row-dmwrap', '.bilibili-player-video-danmaku', '[class*="danmaku"]', '[class*="danmu"]',
    '.bpx-player-subtitle-panel', '.bilibili-player-video-subtitle', '.ytp-caption-window-container', '[class*="subtitle"]',
    '[contenteditable="true"]', '.rd-wrap',
  ].join(',');

  const BLOCK_SELECTOR = 'p,div,section,article,main,aside,blockquote,dd,dt,li,td,figure,hgroup,body';
  const CJK_RE = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/g;
  const LATIN_RE = /[A-Za-z]/g;

  let settings = null;
  let worker = null;
  let generation = 0;
  let extractionEpoch = 0;
  let nodeIdSeq = 1;
  let blockIdSeq = 1;

  const nodeRegistry = new Map(); // nodeId -> {textNode, text, scores, wrap, runs}
  const nodeEpoch = new WeakMap(); // textNode -> epoch（判断是否已提取）
  const textNodeToId = new WeakMap(); // textNode -> nodeId
  let elementBlocks = new WeakMap(); // block element -> blockId（单次提取会话内）

  let lastAnalysisKey = null;
  let analyzeInFlight = false;
  let pendingMutation = false;
  let fullRetry = 0;
  let pendingRender = [];
  let renderScheduled = false;
  let mutationTimer = null;
  let observer = null;
  let scoreResolveQueue = [];

  // ---------- 设置 ----------

  let cachedDefaults = null;

  async function loadDefaults() {
    if (cachedDefaults) return cachedDefaults;
    const res = await fetch(chrome.runtime.getURL('worker/defaults.json'));
    cachedDefaults = await res.json();
    return cachedDefaults;
  }

  function deepMerge(base, over) {
    if (over === null || over === undefined) return base;
    if (typeof base !== 'object' || Array.isArray(base) || base === null) return over;
    if (typeof over !== 'object' || Array.isArray(over)) return over;
    const out = { ...base };
    for (const k of Object.keys(over)) out[k] = deepMerge(base[k], over[k]);
    return out;
  }

  async function loadSettings() {
    const defaults = await loadDefaults();
    const stored = await chrome.storage.local.get(['rd-settings', 'rd-custom']);
    const custom = stored['rd-custom'] || { stop: [], content: [] };
    const s = deepMerge(defaults, stored['rd-settings'] || {});
    s.customStop = custom.stop || [];
    s.customContent = custom.content || [];
    return s;
  }

  function analysisKey(s) {
    const { strength, fade, fadeStyle, ...rest } = s;
    return JSON.stringify(rest);
  }

  // 网站名单：仅禁用 = 名单外都处理；启用 = 只处理名单内网站
  function pageHost() {
    try { return window.top.location.hostname; } catch (e) { return location.hostname; }
  }

  function siteAllowed(s) {
    const list = Array.isArray(s.sitelist) ? s.sitelist : [];
    const hit = list.some((u) => RDSite.sameSite(u, pageHost()));
    return s.siteMode === 'allow' ? hit : !hit;
  }

  function isActive() {
    return !!settings && settings.mode !== 'off' && siteAllowed(settings);
  }

  // ---------- worker ----------

  function createWorker() {
    try {
      const url = chrome.runtime.getURL('worker/analysis-worker.js');
      let w;
      if (/^(https?|file):/.test(url) || url.startsWith('/')) {
        // 桌面壳（本地服务）里 blob+import 的模块 worker 会被拦，直接以 URL 创建
        w = new Worker(url, { type: 'module' });
      } else {
        const blob = new Blob([`import ${JSON.stringify(url)};`], { type: 'text/javascript' });
        w = new Worker(URL.createObjectURL(blob), { type: 'module' });
      }
      w.onmessage = onWorkerMessage;
      w.onerror = (e) => console.warn('[rd] worker error', e);
      return w;
    } catch (e) {
      console.warn('[rd] 无法创建分析 worker', e);
      return null;
    }
  }

  function onWorkerMessage(e) {
    const msg = e.data;
    if (msg.type === 'result') {
      for (const n of msg.nodes) {
        const rec = nodeRegistry.get(n.nodeId);
        if (rec) rec.scores = n.scores;
      }
    } else if (msg.type === 'done' || msg.type === 'error') {
      if (msg.type === 'error') console.warn('[rd] worker:', msg.message);
      const resolvers = scoreResolveQueue;
      scoreResolveQueue = [];
      for (const r of resolvers) r();
    }
  }

  function workerScore(nodeIds) {
    return new Promise((resolve) => {
      if (!worker) return resolve();
      scoreResolveQueue.push(resolve);
      worker.postMessage({ type: 'score', nodeIds: nodeIds || null });
      setTimeout(() => {
        const idx = scoreResolveQueue.indexOf(resolve);
        if (idx >= 0) {
          scoreResolveQueue.splice(idx, 1);
          // 超时说明 worker 已卡死：丢弃它，下次分析重建
          console.warn('[rd] 评分超时，重建 worker');
          try { worker.terminate(); } catch (e) {}
          worker = null;
          resolve();
        }
      }, 120000);
    });
  }

  // ---------- 提取 ----------

  function countCjk(text) {
    const m = text.match(CJK_RE);
    return m ? m.length : 0;
  }

  function countLatin(text) {
    const m = text.match(LATIN_RE);
    return m ? m.length : 0;
  }

  // 隐藏文本照样分析与渲染（之后被显示出来时已经是虚化好的），
  // 但不计入统计与 TF-IDF，避免 display:none 的模板文本拉偏阈值
  function isRendered(el, cache) {
    let v = cache.get(el);
    if (v === undefined) {
      v = typeof el.checkVisibility === 'function'
        ? el.checkVisibility({ checkVisibilityCSS: true })
        : el.getClientRects().length > 0;
      cache.set(el, v);
    }
    return v;
  }

  // 开放 Shadow DOM 也要遍历（readest 的 foliate 查看器、部分站点组件）
  function collectRoots() {
    const roots = [];
    const queue = [document];
    while (queue.length) {
      const root = queue.shift();
      roots.push(root);
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) queue.push(el.shadowRoot);
      }
    }
    return roots;
  }

  function extractNodes() {
    const blocks = [];
    const blockMap = new Map();
    const visCache = new Map();
    const roots = collectRoots();
    let n;
    for (const root of roots) {
      const walker = document.createTreeWalker(root === document ? document.body : root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          const val = node.nodeValue;
          if (!val) return NodeFilter.FILTER_REJECT;
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (nodeEpoch.get(node) === extractionEpoch) return NodeFilter.FILTER_REJECT;
          const inTextLayer = !!parent.closest('.textLayer');
          // PDF 文字层：只在 canvas 补丁激活时参与（为 canvas 重绘提供分数）；否则跳过省算力
          if (inTextLayer && document.documentElement.dataset.rdCanvas !== '1') return NodeFilter.FILTER_REJECT;
          if (parent.closest(SKIP_SELECTOR)) return NodeFilter.FILTER_REJECT;
          if (inTextLayer) return NodeFilter.FILTER_ACCEPT;
          if (val.trim().length < 2) return NodeFilter.FILTER_REJECT;
          if (countCjk(val) < 2 && countLatin(val) < 2) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      while ((n = walker.nextNode())) {
        const parent = n.parentElement;
        const hidden = !isRendered(parent, visCache);
        const inTextLayer = !!parent.closest('.textLayer');
        const blockEl = parent.closest(BLOCK_SELECTOR) || parent;
        let blockId = elementBlocks.get(blockEl);
        if (blockId === undefined) {
          blockId = blockIdSeq++;
          elementBlocks.set(blockEl, blockId);
        }
        const nodeId = nodeIdSeq++;
        const text = n.nodeValue;
        nodeEpoch.set(n, extractionEpoch);
        textNodeToId.set(n, nodeId);
        nodeRegistry.set(nodeId, { textNode: n, text, scores: null, wrap: null, runs: null, hidden, noWrap: inTextLayer });
        let nodes = blockMap.get(blockId);
        if (!nodes) { nodes = []; blockMap.set(blockId, nodes); blocks.push({ blockId, nodes }); }
        nodes.push({ nodeId, text, hidden });
      }
    }
    return blocks;
  }

  // ---------- 分析 ----------

  async function fullAnalysis() {
    const gen = ++generation;
    teardownRender();
    nodeRegistry.clear();
    extractionEpoch++;
    elementBlocks = new WeakMap();
    blockIdSeq = 1;
    analyzeInFlight = true;
    try {
      const blocks = extractNodes();
      console.info('[rd] extracted blocks:', blocks.length, 'nodes:', blocks.reduce((s, b) => s + b.nodes.length, 0));
      // 空帧（阅读器的预加载 iframe 等）不建 worker：每个 worker 都要各自加载 ONNX 模型
      if (blocks.length === 0) return;
      if (!worker) worker = createWorker();
      if (!worker) return;
      worker.postMessage({ type: 'settings', settings, rebuild: true });
      let batch = [];
      let batchSize = 0;
      const flush = () => {
        if (batch.length) {
          worker.postMessage({ type: 'submit', blocks: batch });
          batch = [];
          batchSize = 0;
        }
      };
      for (const b of blocks) {
        const chars = b.nodes.reduce((s, x) => s + x.text.length, 0);
        if (batchSize + chars > 60000 || batch.length >= 40) flush();
        batch.push(b);
        batchSize += chars;
      }
      flush();
      await workerScore(null);
      if (gen !== generation) return;
      let scored = 0;
      for (const rec of nodeRegistry.values()) if (rec.scores) scored++;
      if (scored === 0 && fullRetry < 2) {
        fullRetry++;
        console.warn('[rd] 无评分结果，重建 worker 后重试', fullRetry);
        if (worker) { try { worker.terminate(); } catch (e) {} worker = null; }
        analyzeInFlight = false;
        await fullAnalysis();
        return;
      }
      fullRetry = 0;
      const st = computeStats();
      console.info('[rd] scored nodes:', scored, 'stats:', st && JSON.stringify({ mean: st.mean, median: st.median, min: st.min, n: st.sorted.length }));
      scheduleRenderAll();
    } finally {
      if (gen === generation) {
        analyzeInFlight = false;
        // 分析期间到达的 DOM 变更会被 observer 丢掉，这里补一次
        if (pendingMutation) {
          pendingMutation = false;
          scheduleMutationAnalysis(300);
        }
      }
    }
  }

  async function incrementalAnalysis(newBlocks) {
    if (newBlocks.length === 0) return;
    if (!worker) { await fullAnalysis(); return; } // worker 被超时重建过，状态已丢，走全量
    const gen = generation;
    analyzeInFlight = true;
    try {
      worker.postMessage({ type: 'submit', blocks: newBlocks });
      const nodeIds = [];
      for (const b of newBlocks) for (const n of b.nodes) nodeIds.push(n.nodeId);
      await workerScore(nodeIds);
      if (gen !== generation) return;
      computeRuns();
      for (const id of nodeIds) {
        const rec = nodeRegistry.get(id);
        if (rec && rec.scores && rec.runs && rec.runs.length && !rec.wrap) pendingRender.push(id);
      }
      scheduleRenderChunk();
    } finally {
      if (gen === generation) {
        analyzeInFlight = false;
        if (pendingMutation) {
          pendingMutation = false;
          scheduleMutationAnalysis(300);
        }
      }
    }
  }

  // ---------- 虚化计算与渲染 ----------

  function computeStats() {
    const all = [];
    for (const rec of nodeRegistry.values()) {
      if (!rec.scores) continue;
      if (rec.hidden) continue; // 隐藏文本不参与阈值统计
      const { scores, text } = rec;
      for (let i = 0; i < scores.length; i++) {
        if (/\s/.test(text[i])) continue;
        all.push(scores[i]);
      }
    }
    if (all.length === 0) return null;
    let sum = 0;
    let min = Infinity;
    for (const v of all) { sum += v; if (v < min) min = v; }
    const mean = sum / all.length;
    all.sort((a, b) => a - b);
    const median = all.length % 2
      ? all[(all.length - 1) / 2]
      : (all[all.length / 2 - 1] + all[all.length / 2]) / 2;
    return { sorted: all, mean, median, min };
  }

  function makeFadeFn(stats) {
    const cfg = settings.fade;
    // 挡位 25..100 线性插值：设置项的两个端点即最轻/最强挡的实际取值
    const t = Math.max(0, Math.min(1, (settings.strength - 25) / 75));
    let ratio = cfg.ratioLight + t * (cfg.ratioStrong - cfg.ratioLight);
    const skew = stats.mean - stats.median;
    if (skew < -cfg.skewThreshold) ratio += cfg.skewAdjust; // 均值低于中位数：低分尾巴长，噪音更多
    else if (skew > cfg.skewThreshold) ratio -= cfg.skewAdjust;
    ratio = Math.max(0.02, Math.min(0.65, ratio));
    const arr = stats.sorted;
    const targetIdx = Math.min(arr.length - 1, Math.max(0, Math.round(ratio * (arr.length - 1))));
    const snapWin = cfg.snapWindow ?? 0.1;
    const threshold = snapWin > 0 ? snapToValley(arr, targetIdx, snapWin) : arr[targetIdx];
    const floor = cfg.opacityStrong + (1 - t) * (cfg.opacityLight - cfg.opacityStrong);
    const span = Math.max(1e-6, threshold - stats.min);
    console.info('[rd] fade ratio:', ratio.toFixed(3), 'threshold:', threshold, 'floor:', floor.toFixed(2), 'style:', settings.fadeStyle || 'curve');
    if ((settings.fadeStyle || 'curve') === 'binary') {
      // 二元虚化：所有挡位统一透明度
      const op = Math.round(Math.max(0.05, Math.min(0.95, cfg.binaryOpacity ?? 0.5)) * 20) / 20;
      return (score) => (score >= threshold ? 1 : op);
    }
    return (score) => {
      if (score >= threshold) return 1;
      const t = (score - stats.min) / span;
      const op = floor + t * (0.95 - floor);
      return Math.round(Math.max(floor, Math.min(0.95, op)) * 20) / 20;
    };
  }

  // 谷底吸附：得分是离散值，分位数切点可能落在密集平票群中间。
  // 在"实际虚化比例与目标偏差 ≤ window"的候选切点里，选"切割处两侧密度之和最小"的分数值做阈值，
  // 让切割点尽量落在语义簇之间的低谷，而不是劈开同类字。
  function snapToValley(arr, targetIdx, window) {
    // 提取互异分数值及其计数（得分取值范围有限，组数很少）
    const groups = []; // {val, count}
    for (let i = 0; i < arr.length; ) {
      const v = arr[i];
      let j = i + 1;
      while (j < arr.length && arr[j] === v) j++;
      groups.push({ val: v, count: j - i });
      i = j;
    }
    if (groups.length <= 2) return arr[targetIdx];
    const winCount = Math.max(1, Math.round(window * arr.length));
    // 阈值取 groups[k].val：>=val 保留，<val 虚化，虚化字符数 = k 之前各组之和。
    // 窗口约束的是实际虚化量与目标量的偏差——切点索引在窗口内不代表虚化比例在窗口内
    // （离散平票群很宽时，索引差 1 可能对应十几个百分点的偏差）。
    let acc = 0;
    let best = -1;
    let bestCost = Infinity;
    for (let k = 0; k < groups.length; k++) {
      const faded = acc;
      acc += groups[k].count;
      const dist = Math.abs(faded - targetIdx);
      if (dist > winCount) continue;
      const density = groups[k].count + (k > 0 ? groups[k - 1].count : 0);
      const cost = density * arr.length + dist; // 密度优先，同密度取更贴近目标的切点
      if (cost < bestCost) { bestCost = cost; best = k; }
    }
    return best >= 0 ? groups[best].val : arr[targetIdx];
  }

  function computeRuns() {
    const stats = computeStats();
    if (!stats) return;
    const fadeFn = makeFadeFn(stats);
    for (const rec of nodeRegistry.values()) {
      if (!rec.scores) { rec.runs = null; continue; }
      const { scores, text } = rec;
      const runs = [];
      let runStart = -1;
      let runOp = 1;
      for (let i = 0; i < scores.length; i++) {
        const op = /\s/.test(text[i]) ? 1 : fadeFn(scores[i]);
        if (op < 0.95) {
          if (runStart < 0 || op !== runOp) {
            if (runStart >= 0) runs.push([runStart, i, runOp]);
            runStart = i;
            runOp = op;
          }
        } else if (runStart >= 0) {
          runs.push([runStart, i, runOp]);
          runStart = -1;
        }
      }
      if (runStart >= 0) runs.push([runStart, scores.length, runOp]);
      rec.runs = runs.length ? runs : null;
    }
  }

  function scheduleRenderAll() {
    computeRuns();
    pendingRender = [];
    for (const [id, rec] of nodeRegistry) {
      if (rec.runs && !rec.wrap && !rec.noWrap) pendingRender.push(id);
    }
    console.info('[rd] render queue:', pendingRender.length);
    scheduleRenderChunk();
  }

  function scheduleRenderChunk() {
    if (renderScheduled) return;
    renderScheduled = true;
    requestAnimationFrame(renderChunk);
    // 后台标签页/无头环境下 rAF 可能停发，用定时器兜底
    setTimeout(() => { if (renderScheduled) renderChunk(); }, 120);
  }

  let renderRunning = false;
  function renderChunk() {
    if (renderRunning) return;
    renderRunning = true;
    const start = performance.now();
    while (pendingRender.length && performance.now() - start < 12) {
      renderNode(pendingRender.shift());
    }
    renderRunning = false;
    if (pendingRender.length) {
      renderScheduled = false; // 重新登记 rAF/兜底定时器，否则大批量节点会停在第二批
      scheduleRenderChunk();
    } else {
      renderScheduled = false;
      scheduleCanvasMaps();
    }
  }

  function renderNode(nodeId) {
    const rec = nodeRegistry.get(nodeId);
    if (!rec || !rec.runs || rec.wrap) return;
    const tn = rec.textNode;
    if (!tn || !tn.isConnected || tn.nodeValue !== rec.text) { rec.runs = null; return; }
    const wrap = document.createElement('span');
    wrap.className = 'rd-wrap';
    let pos = 0;
    for (const [s, e, op] of rec.runs) {
      if (s > pos) wrap.appendChild(document.createTextNode(rec.text.slice(pos, s)));
      const span = document.createElement('span');
      span.className = 'rd-fade';
      span.style.opacity = String(op);
      span.textContent = rec.text.slice(s, e);
      wrap.appendChild(span);
      pos = e;
    }
    if (pos < rec.text.length) wrap.appendChild(document.createTextNode(rec.text.slice(pos)));
    tn.replaceWith(wrap);
    rec.wrap = wrap;
  }

  function teardownRender() {
    for (const [id, rec] of nodeRegistry) {
      if (rec.wrap && rec.wrap.isConnected) {
        const tn = document.createTextNode(rec.text);
        rec.wrap.replaceWith(tn);
        rec.textNode = tn; // 重渲染要用新节点，否则 isConnected 检查失败
        textNodeToId.set(tn, id);
      }
      rec.wrap = null;
    }
    pendingRender = [];
  }

  function rerenderFromCache() {
    teardownRender();
    for (const rec of nodeRegistry.values()) rec.runs = null;
    scheduleRenderAll();
  }

  // ---------- canvas 虚化（PDF 查看器） ----------
  // MAIN 世界补丁（canvas-fade-main.js）扣住文字绘制，这里按文字层的字符顺序回传每字透明度

  let canvasMapTimer = null;

  function scheduleCanvasMaps() {
    if (document.documentElement.dataset.rdCanvas !== '1') return;
    if (canvasMapTimer) return;
    canvasMapTimer = setTimeout(() => { canvasMapTimer = null; buildCanvasMaps(); }, 120);
  }

  function charOps(rec) {
    const runs = rec.runs;
    if (!runs) return null;
    const ops = [];
    let ri = 0;
    for (let i = 0; i < rec.text.length; i++) {
      while (ri < runs.length && i >= runs[ri][1]) ri++;
      ops.push(ri < runs.length && i >= runs[ri][0] ? runs[ri][2] : 1);
    }
    return ops;
  }

  function buildCanvasMaps() {
    if (document.documentElement.dataset.rdCanvas !== '1') return;
    const roots = collectRoots();
    const canvases = [];
    const layers = [];
    for (const root of roots) {
      for (const c of root.querySelectorAll('canvas')) if (c.dataset.rdCanvasId) canvases.push(c);
      for (const l of root.querySelectorAll('.textLayer')) layers.push(l);
    }
    if (!canvases.length) return;
    for (const layer of layers) {
      const lr = layer.getBoundingClientRect();
      if (!lr.width || !lr.height) continue;
      let best = null;
      let bestArea = 0;
      for (const c of canvases) {
        const r = c.getBoundingClientRect();
        const w = Math.min(lr.right, r.right) - Math.max(lr.left, r.left);
        const h = Math.min(lr.bottom, r.bottom) - Math.max(lr.top, r.top);
        const area = w > 0 && h > 0 ? w * h : 0;
        if (area > bestArea) { bestArea = area; best = c; }
      }
      if (!best) continue;
      // 画布可能被收养到别的帧展示：坐标用画布局部 CSS 坐标，跨帧可比
      const cr = best.getBoundingClientRect();
      const walker = document.createTreeWalker(layer, NodeFilter.SHOW_TEXT);
      const ops = [];
      const pts = [];
      let ready = true;
      let n;
      while ((n = walker.nextNode())) {
        const rec = nodeRegistry.get(textNodeToId.get(n));
        if (!rec || !rec.scores) { ready = false; break; }
        const o = (rec.runs && charOps(rec)) || Array.from(rec.text, () => 1);
        for (let i = 0; i < o.length; i++) {
          let x = 0;
          let y = 0;
          try {
            const range = document.createRange();
            range.setStart(n, i);
            range.setEnd(n, i + 1);
            const r = range.getBoundingClientRect();
            x = (r.left + r.width / 2) - cr.left;
            y = (r.bottom - r.height * 0.25) - cr.top;
          } catch (e) {
            ready = false;
            break;
          }
          ops.push(o[i]);
          pts.push([Math.round(x), Math.round(y)]);
        }
        if (!ready) break;
      }
      // 未打完分就先不发，避免用全 1 的映射把文字提前画掉；发往顶层帧（绘制发生处）
      if (!ready || !ops.length) continue;
      console.info('[rd] canvas maps: post', best.dataset.rdCanvasId, ops.length);
      (window.top || window).postMessage({ __rd: 'canvas-map', canvasId: best.dataset.rdCanvasId, ops, pts }, '*');
    }
  }

  // ---------- 动态内容 ----------

  function scheduleMutationAnalysis(delay) {
    if (mutationTimer !== null) return;
    mutationTimer = setTimeout(() => {
      mutationTimer = null;
      processNewContent();
    }, delay);
  }

  function isSelfMutation(m) {
    for (const n of m.removedNodes) {
      if (n.nodeType === 1 && n.classList && n.classList.contains('rd-wrap')) return true;
    }
    for (const n of m.addedNodes) {
      if (n.nodeType === 1 && n.classList && n.classList.contains('rd-wrap')) return true;
    }
    return false;
  }

  function setupObserver() {
    if (observer) observer.disconnect();
    const observed = new WeakSet();
    const attach = () => {
      for (const root of collectRoots()) {
        if (observed.has(root)) continue;
        observed.add(root);
        try {
          observer.observe(root === document ? document.body : root, { childList: true, subtree: true, characterData: true });
        } catch (e) {}
      }
    };
    observer = new MutationObserver((mutations) => {
      if (!isActive()) return;
      if (analyzeInFlight) {
        if (mutations.some((m) => !isSelfMutation(m))) pendingMutation = true;
        return;
      }
      let real = false;
      for (const m of mutations) {
        if (isSelfMutation(m)) continue;
        if (m.type === 'characterData') {
          const tn = m.target;
          const id = textNodeToId.get(tn);
          if (id !== undefined) {
            const rec = nodeRegistry.get(id);
            if (rec && rec.wrap && rec.wrap.isConnected) {
              rec.wrap.replaceWith(tn); // 还原为文本节点，交由页面继续修改
              rec.wrap = null;
            }
            nodeRegistry.delete(id);
            nodeEpoch.set(tn, -1);
          }
          real = true;
          continue;
        }
        for (const n of m.addedNodes) {
          if (n.nodeType === 3 || (n.nodeType === 1 && !(n.classList && n.classList.contains('rd-wrap')))) {
            real = true;
            break;
          }
        }
        if (real) break;
      }
      if (!real) return;
      attach(); // 新出现的 shadow host 也要纳入观察
      scheduleMutationAnalysis(700); // 合并等待期间的变化，避免播放器持续更新把分析无限推迟
    });
    attach();
  }

  async function processNewContent() {
    if (!isActive()) return;
    if (analyzeInFlight) { pendingMutation = true; return; }
    const blocks = extractNodes();
    if (blocks.length === 0) return;
    await incrementalAnalysis(blocks);
  }

  // ---------- 入口 ----------

  function disableRender() {
    generation++;
    teardownRender();
    nodeRegistry.clear();
    extractionEpoch++;
    lastAnalysisKey = null;
    window.postMessage({ __rd: 'canvas-mode', enabled: false }, '*');
  }

  async function applySettings() {
    const prevKey = lastAnalysisKey;
    settings = await loadSettings();
    if (!isActive()) {
      disableRender();
      return;
    }
    window.postMessage({ __rd: 'canvas-mode', enabled: true }, '*');
    const key = analysisKey(settings);
    if (lastAnalysisKey === null || prevKey === null || key !== prevKey) {
      lastAnalysisKey = key;
      await fullAnalysis();
    } else {
      rerenderFromCache();
    }
  }

  async function init() {
    console.info('[rd] content script init', location.href);
    try {
      settings = await loadSettings();
    } catch (e) {
      console.warn('[rd] 设置加载失败', e);
      return;
    }
    if (document.body) setupObserver();
    else document.addEventListener('DOMContentLoaded', () => setupObserver(), { once: true });

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === 'rd-apply') {
        applySettings().then(() => sendResponse({ ok: true }));
        return true;
      }
      if (msg && msg.type === 'rd-ping') {
        sendResponse({ ok: true, mode: settings ? settings.mode : 'unknown' });
      }
      return false;
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes['rd-settings'] || changes['rd-custom'])) {
        const modeChange = changes['rd-settings'];
        const nextMode = modeChange?.newValue?.mode;
        if (nextMode !== modeChange?.oldValue?.mode && (nextMode === 'off' || nextMode === 'precise')) {
          if (settings) settings.mode = nextMode;
          if (nextMode === 'off') {
            disableRender();
            return;
          }
          window.postMessage({ __rd: 'canvas-mode', enabled: true }, '*');
        }
        applySettings().catch((e) => console.warn('[rd] 设置更新失败', e));
      }
    });
    window.addEventListener('message', (e) => {
      if (e.data && e.data.__rd === 'canvas-need') scheduleCanvasMaps();
    });

    if (isActive() && document.body) {
      lastAnalysisKey = analysisKey(settings);
      await fullAnalysis();
    } else if (!isActive()) {
      window.postMessage({ __rd: 'canvas-mode', enabled: false }, '*');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init(), { once: true });
  } else {
    init();
  }
})();
